/* 
Code adapted from the structure that can be found on the link below
Title: Using a Public API for Beginners
Author: iEatWebsites
Date: 30/04/2020 (last accessed)
Availability: https://www.youtube.com/watch?v=InoAIgBZIEA&t=364s
*/

//Getting data from user input and putting into variables
var from
$('#fromCurrency').on('change', function(){
    from = $(this).val()
})
var to
$('#toCurrency').on('change', function(){
    to = $(this).val()
})

var amount
$('#amount').on('change', function(){
    amount = $(this).val()
})

//Event handler when the button is clicked
$('#convertbtn').click(function(){
    if (from == to){
        alert("Sorry, the currencies are the same.")
    } else{
    $('#result').toggle();
    convertCurrency()
    }
})

//Function to get the data from the API and show to the user
function convertCurrency(){
    //Getting the conversion fom the API
    $.getJSON("https://api.frankfurter.app/latest?amount="+ amount +"&from="+ from +"&to="+ to +"", function(data){
    
    //Parsing JSON data to string
    var result = Object.values(data.rates);
    
    //Putting the result into the HTML
    document.getElementById('output').innerHTML = "Base date for conversion: " + data.date;
    document.getElementById('output2').innerHTML = "Value to convert: " + amount;
    document.getElementById('output4').innerHTML = "The result is: " + result + " " + to;
    })
    //Getting the rate from the API
    $.getJSON("https://api.frankfurter.app/latest?to="+ to +"", function(data1){

        //Parsing JSON data to string
        var rate = Object.values(data1.rates);

        //Putting the result into the HTML
        document.getElementById('output3').innerHTML = "Rate: " + rate + " " + to;
    })

}